
package DTO;


public class CustomerDTO {
    
    int customerID;
String fullName; 
String accountNumber;
double balance;

    public CustomerDTO(int customerID, String fullName, String accountNumber, double balance) {
        this.customerID = customerID;
        this.fullName = fullName;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    
}
